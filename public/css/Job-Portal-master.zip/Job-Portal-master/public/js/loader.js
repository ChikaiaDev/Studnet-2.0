var loader-wrapper = document.getElementById("loader-wrapper");

window.addEventListener('load', function(){
    loader-wrapper.style.display ='none';
})